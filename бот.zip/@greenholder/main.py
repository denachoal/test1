
import json, asyncio, os, time
import aiogram.utils.markdown as md
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters import Text
from aiogram.dispatcher.filters.state import StatesGroup, State
from aiogram.types import ParseMode, message
from aiogram.utils import executor
from threading import Thread
from multiprocessing.context import Process
from datetime import datetime

from state import EditPost

from keyboard import *
from sqlite import *
from config import *
from text import *

bot = Bot(token=bot_token, parse_mode='html')
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)


@dp.message_handler(state=EditPost.get_text)
async def message_handler_edit_post(message: types.Message, state: FSMContext):
	async with state.proxy() as data: 
		message_text_add = data['message_text_add']
		user_id = data['user_id']
		file_id = data['file_id']
	await message.answer_photo(file_id, caption=message.text+f'\n\n{message_text_add}', reply_markup=accept_keyboard(user_id))

@dp.message_handler(state='*')
async def message_handler(message: types.Message, state: FSMContext):
	print(message.chat.id)
	await message.answer(main_text)

@dp.message_handler(content_types=['photo'], state='*')
async def message_handler_post(message: types.Message, state: FSMContext):
	user_id = message.from_user.id
	posts_count = await get_user_posts_count(user_id)
	# if posts_count>0:
	# 	await message.answer(too_many_requests_text)
	# 	return
	message_text = message.caption
	file_id = message.photo[0].file_id
	user_name = message.from_user.first_name
	user_username = message.from_user.username
	if message_text is None:
		await message_handler(message, state)
		return
	message_text+=f'\n\nНаписать автору: <a href="tg://user?id={user_id}">{user_name}</a> @{user_username}'
	await bot.send_photo(admin_chat_id, file_id, caption=message_text, reply_markup=accept_keyboard(user_id))
	await message.answer(success_request_text)
	await add_post_hisotry(user_id)

@dp.callback_query_handler(text_startswith='accept_post', state='*')
async def callback_accept_post(call: types.CallbackQuery, state: FSMContext):
	user_id = call.data.split(';')[1]
	message_text, info = call.message.caption.rsplit('Написать автору: ')
	first_name, username = info.split()
	message_text+=f'Написать автору: <a href="tg://user?id={user_id}">{first_name}</a> @{first_name}'
	file_id = call.message.photo[0].file_id
	await bot.send_photo(channel_id, file_id, caption=message_text, reply_markup=post_keyboard())
	await bot.send_message(user_id, success_post_text)
	await call.message.edit_reply_markup(None)
	await call.message.edit_caption(message_text+'\n\n<i>Объявление опубликовано</i>')

@dp.callback_query_handler(text_startswith='cancel_post', state='*')
async def callback_cancel_post(call: types.CallbackQuery, state: FSMContext):
	user_id = call.data.split(';')[1]
	message_text = message.text
	await bot.send_message(user_id, worng_post_text)
	await call.message.edit_reply_markup(None)
	await call.message.edit_caption(message_text+'\n\n<i>Объявление отклонено</i>')

@dp.callback_query_handler(text_startswith='edit_post', state='*')
async def callback_edit_post(call: types.CallbackQuery, state: FSMContext):
	user_id = call.data.split(';')[1]
	message_text, info = call.message.caption.rsplit('Написать автору: ')
	first_name, username = info.split()
	file_id = call.message.photo[0].file_id

	message_text_add = f'Написать автору: <a href="tg://user?id={user_id}">{first_name}</a> @{first_name}'
	async with state.proxy() as data:
		data['message_text_add'] = message_text_add
		data['user_id'] = user_id
		data['file_id'] = file_id
	await call.message.delete()
	await call.message.answer('Укажите новый текст объявления:')
	await EditPost.get_text.set()



if __name__ == '__main__':
	loop = asyncio.new_event_loop()
	asyncio.set_event_loop(loop)
	executor.start_polling(dp, skip_updates=True)