#Токен бота
bot_token = '5328033246:AAHq-1hSGl8OFLsGn7SgTqMZ9-cCFW1RTfo'

#Канал, в который публикуются объявления
channel_id = -1001761238568

#Чат с модерацией
admin_chat_id = -713114061

#Ссылка на бота
bot_link = 'https://t.me/vape_astrabot'

#Ссылка на админа(реклама)
admin_link = 'https://t.me/greenholder'