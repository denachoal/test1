import aiosqlite
import asyncio
from datetime import datetime, timedelta

async def create_table_post_history():
	async with aiosqlite.connect('Main.db') as db:
		cursor = await db.cursor()
		# await cursor.execute('DROP TABLE post_history')
		await cursor.execute('CREATE TABLE IF NOT EXISTS post_history(num INTEGER, user_id BIGINT, `date` date, PRIMARY KEY("num" AUTOINCREMENT))')

asyncio.run(create_table_post_history())

async def add_post_hisotry(user_id):
	async with aiosqlite.connect('Main.db') as db:
		cursor = await db.cursor()
		date_now = datetime.now()
		await cursor.execute('INSERT INTO post_history(user_id, `date`) VALUES (?, ?)', (user_id, date_now))
		await db.commit()

async def get_user_posts_count(user_id):
	async with aiosqlite.connect('Main.db') as db:
		cursor = await db.cursor()
		date_day = datetime.now()-timedelta(days=1)
		await cursor.execute('SELECT Count(*) FROM post_history WHERE user_id = ? AND `date`>?', (user_id, date_day))
		return (await cursor.fetchone())[0]
		