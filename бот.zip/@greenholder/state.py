from aiogram.dispatcher.filters.state import State, StatesGroup

class EditPost(StatesGroup):
    get_text = State() 