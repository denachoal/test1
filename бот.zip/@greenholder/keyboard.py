from aiogram import types

from config import bot_link, admin_link

def accept_keyboard(user_id):
	markup = types.InlineKeyboardMarkup(row_width=2)
	markup.add(
		types.InlineKeyboardButton(text='✅ Принять', callback_data=f'accept_post;{user_id}'),
		types.InlineKeyboardButton(text='❌ Отклонить', callback_data=f'cancel_post;{user_id}'),
		types.InlineKeyboardButton(text='✏️ Редактировать', callback_data=f'edit_post;{user_id}')
			)
	return markup

def post_keyboard():
	markup = types.InlineKeyboardMarkup(row_width=1)
	markup.add(
		types.InlineKeyboardButton(text='Добавить объявление', url=bot_link),
		types.InlineKeyboardButton(text='Реклама', url=admin_link)
		)
	return markup